import 'package:flutter/material.dart';
 Text textcostam( String data,double? fontSize,Color? color,{FontWeight? fontWeight}) {
    return Text(
         data,
        style: TextStyle(fontSize: fontSize, color:color,fontWeight:fontWeight ),
      );
  }