import 'package:flutter/material.dart';

TextFormField textformfiles(TextEditingController? controller,
    {String? hintText,
    Widget? label,
    TextInputType? keyboardType,
    int? maxLength,
    Widget? suffixIcon,
    Widget? prefixIcon,
    String? Function(String?)? validator,
    Function(String)? onChanged,
    String? labelText,
    TextCapitalization textCapitalization = TextCapitalization.none,FocusNode? focusNode,
    bool autofocus = false,
    bool readOnly = false}) {
  return TextFormField(
    keyboardType: keyboardType,
    textCapitalization: TextCapitalization.none,
    controller: controller,focusNode:focusNode ,
    autofocus: autofocus,
    readOnly: readOnly,
    maxLength: maxLength,
    validator: validator,
    onChanged: onChanged,
    decoration: InputDecoration(
      suffixIcon: suffixIcon,
      labelText: labelText,
      counterText: "",
      prefixIcon: prefixIcon,
      label: label,
      hintText: hintText,
      isDense: true,
      contentPadding: const EdgeInsets.only(top: 28, left: 15, right: 10),
      border: InputBorder.none,
      focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: const BorderSide(color: Colors.black)),
      errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: const BorderSide(color: Colors.black)),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: const BorderSide(color: Colors.black)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: const BorderSide(color: Colors.black)),
      disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: const BorderSide(color: Colors.black)),
    ),
  );
}
