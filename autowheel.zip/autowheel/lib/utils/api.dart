// import 'package:flutter/material.dart';
// // ignore_for_file: non_constant_identifier_names, prefer_interpolation_to_compose_strings, avoid_print, empty_catches

// import 'dart:convert';
// // import 'package:http/http.dart' as http;
// // ignore: prefer_typing_uninitialized_variables
// var data;
// Future SignupApi(var fname, var lname, var email, var password) async {
//   try {
//     // var responce = await http.post(
//         Uri.parse(
//             "https://myworkdesk.tech/development/pinpoint-apis-main/public/auth/register"),
//         body: {
//           "fname":fname,
//           "lname": lname,
//           "email": email,
//           "password": password 
//         });
//     if (responce.statusCode == 200) {
//       data = json.decode(responce.body);
//       if (data["status"] == true) {
//         print("message------->" + data["message"].toString());
//       }
//     }
//   } catch (e) {}
// }
// Future LoginApi(var email, var password) async {
//   try {
//     var responce = await http.post(
//         Uri.parse(
//             "https://myworkdesk.tech/development/pinpoint-apis-main/public/auth/login"),
//         body: {"email": email, "password": password});
//     print(responce.body);
//     if (responce.statusCode == 200) {
//       data = json.decode(responce.body);
//     }
//     if (data["status"] == true) {
//       print("massage------------>" + data["message"].toString());
//     }
//   } catch (e) {}
// }
// Future ForgotPasswordApi(
//   var email,
// ) async {
//   try{
//   var responce = await http.post(
//       Uri.parse(
//           "https://myworkdesk.tech/development/pinpoint-apis-main/public/auth/forgot-password"),
//       body: {"email": email, "type": "1"});
//   print(responce.body);
//   if (responce.statusCode == 200) {
//     data = json.decode(responce.body);
//   }
//   if (data["status"] == true) {
//     print("massage---+++++++++++" + data["massage"].toString());
//   }
// }catch(e){}
// }


