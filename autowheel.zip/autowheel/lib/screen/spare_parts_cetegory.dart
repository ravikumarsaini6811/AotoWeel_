import 'package:autowheel/contacts/colors.dart';
// ignore: unused_import
import 'package:autowheel/screen/create_cetegory.dart';
import 'package:autowheel/screen/servicce_Type.dart';
import 'package:autowheel/utils/text.dart';
import 'package:autowheel/utils/textformfildes.dart';
import 'package:flutter/material.dart';

// ignore: camel_case_types
class Spare_Parts_cetegory extends StatefulWidget {
  const Spare_Parts_cetegory({super.key});

  @override
  State<Spare_Parts_cetegory> createState() => _Spare_Parts_cetegoryState();
}

// ignore: camel_case_types
class _Spare_Parts_cetegoryState extends State<Spare_Parts_cetegory> {
  var cetegorycon = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: GestureDetector(
        onTap: () {
          Navigator.push(
              // ignore: prefer_const_constructors
              context,
              MaterialPageRoute(builder: (context) => Service_Name()));
        },
        child: Container(
          height: 50,
          width: 120,
          decoration: BoxDecoration(
              color: const Color.fromARGB(255, 136, 180, 216),
              borderRadius: BorderRadius.circular(10),
              // ignore: prefer_const_literals_to_create_immutables
              boxShadow: [const BoxShadow(blurRadius: 2)]),
          child: Padding(
            padding: const EdgeInsets.only(
              left: 10,
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.add,
                  size: 20,
                ),
                const SizedBox(
                  width: 5,
                ),
                textcostam("Service Type", 15, AppColor.kBlack)
              ],
            ),
          ),
        ),
      ),
      appBar: AppBar(
        iconTheme: const IconThemeData(color: AppColor.kBlack),
        backgroundColor: const Color.fromARGB(255, 82, 198, 86),
        elevation: 5,
        centerTitle: true,
        title: textcostam("Service Type", 18, AppColor.kBlack),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 10, right: 10, left: 10),
        child: Column(
          children: [
            textformfiles(cetegorycon,
                // ignore: body_might_complete_normally_nullable
                validator: (p0) {},
                label: textcostam("Type here", 18, AppColor.kGray),
                prefixIcon: const Icon(Icons.search)),
          ],
        ),
      ),
    );
  }
}
