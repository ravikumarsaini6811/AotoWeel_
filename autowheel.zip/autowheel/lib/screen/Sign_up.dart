import 'package:autowheel/screen/otp_screen.dart';
import 'package:autowheel/utils/text.dart';
import 'package:flutter/material.dart';

import '../contacts/colors.dart';
import '../utils/textformfildes.dart';

class Sign_Up extends StatefulWidget {
  const Sign_Up({super.key});

  @override
  State<Sign_Up> createState() => _Sign_UpState();
}

class _Sign_UpState extends State<Sign_Up> {
  final formkey = GlobalKey<FormState>();
  var Mobilecontroller = TextEditingController();
  var h, w;
  var isshow = false;

  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(color: AppColor.kBlack),
        elevation: 5,
        backgroundColor: const Color.fromARGB(255, 82, 198, 86),
        title: textcostam("Sign Up", 22, AppColor.kBlack),
      ),
      body: Padding(
        padding: EdgeInsets.only(left: 10, right: 10, top: 15),
        child: ListView(
          physics: BouncingScrollPhysics(),
          children: [
            Form(
              key: formkey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 300,
                    width: double.infinity,
                    decoration: BoxDecoration(color: Colors.white),
                    child: Column(
                      children: [
                        Image.asset(
                          "assets/app sign up.jpg",
                          fit: BoxFit.cover,
                          height: h * 0.3289,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  textcostam(
                      "Please enter your phone number", 16, AppColor.kBlack),
                  SizedBox(
                    height: h * 0.03,
                  ),
                  textformfiles(
                    Mobilecontroller,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Enter Your Mobile Number";
                      }
                    },
                    label: textcostam("Phone Number", 16, AppColor.kBlack),
                    keyboardType: TextInputType.number,
                    maxLength: 10,
                    prefixIcon: Icon(
                      Icons.phone,

                      size: h * 0.024,
                      // Color.fromARGB(255, 36, 137, 39),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 2),
                    child: Row(
                      children: [
                        Align(
                          child: SizedBox(
                            width: 13,
                            child: Checkbox(
                                value: isshow,
                                onChanged: (e) {
                                  setState(() {});
                                  isshow = !isshow;
                                }),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        textcostam("I agree to the Terms & Conditions", 16,
                            AppColor.kGray),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: h * 0.04,
                  ),
                  InkWell(
                    onTap: () {
                      if (formkey.currentState!.validate()) {
                        if (isshow == true) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Otp_Ui()));
                        }
                      }
                    },
                    child: Container(
                      height: 40,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: Color(0xFF59B8BE),
                      ),
                      child: Center(
                          child: textcostam("Login", 16, AppColor.kWhite)),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
