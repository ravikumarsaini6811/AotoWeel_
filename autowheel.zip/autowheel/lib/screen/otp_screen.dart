import 'package:autowheel/utils/text.dart';
import 'package:autowheel/utils/textformfildes.dart';
import 'package:flutter/material.dart';

import '../contacts/colors.dart';

class Otp_Ui extends StatefulWidget {
  const Otp_Ui({super.key});

  @override
  State<Otp_Ui> createState() => _Otp_UiState();
}

class _Otp_UiState extends State<Otp_Ui> {
  var optcon = TextEditingController();
  var optcon1 = TextEditingController();
  var optcon2 = TextEditingController();
  var optcon3 = TextEditingController();
  var h, w;
  FocusNode f1 = FocusNode();
  FocusNode f2 = FocusNode();
  FocusNode f3 = FocusNode();
  FocusNode f4 = FocusNode();
  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AppColor.kWhite,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(color: AppColor.kBlack),
        elevation: 5,
        backgroundColor: const Color.fromARGB(255, 82, 198, 86),
        title: textcostam("Verification", 22, AppColor.kBlack),
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10, top: 15),
        child: ListView(
          physics: BouncingScrollPhysics(),
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 300,
                  width: double.infinity,
                  decoration: BoxDecoration(color: Colors.white),
                  child: Column(
                    children: [
                      Image.asset(
                        "assets/WhatsApp Image 2023-08-28 at 4.44.21 PM(1).jpeg",
                        fit: BoxFit.cover,
                        height: h * 0.3289,
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: h * 0.02,
                ),
                textcostam(
                    "OTP has been sent on your registered \nPhone Number xxxxxxxx89",
                    14,
                    AppColor.kGray),
                SizedBox(
                  height: 15,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    SizedBox(
                      width: 40,
                      child: textformfiles(
                        optcon,
                        focusNode: f1,
                        onChanged: (String newVal) {
                          if (newVal.length == 1) {
                            f1.unfocus();
                            FocusScope.of(context).requestFocus(f2);
                          }
                        },
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                      ),
                    ),
                    SizedBox(
                      width: 40,
                      child: textformfiles(
                        optcon1,
                        focusNode: f2,
                        onChanged: (String newVal) {
                          if (newVal.length == 1) {
                            f1.unfocus();
                            FocusScope.of(context).requestFocus(f3);
                          }
                        },
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                      ),
                    ),
                    SizedBox(
                      width: 40,
                      child: textformfiles(
                        optcon2,
                        focusNode: f3,
                        onChanged: (String newVal) {
                          if (newVal.length == 1) {
                            f1.unfocus();
                            FocusScope.of(context).requestFocus(f4);
                          }
                        },
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                      ),
                    ),
                    SizedBox(
                      width: 40,
                      child: textformfiles(
                        optcon3,
                        focusNode: f4,
                        onChanged: (String newVal) {
                          if (newVal.length == 1) {
                            f1.unfocus();
                            FocusScope.of(context).requestFocus();
                          }
                        },
                        keyboardType: TextInputType.number,
                        maxLength: 1,
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    textcostam("Didn't Receive Code? ", 16, AppColor.kGray),
                    textcostam("Resend Now ", 16, AppColor.kBlue),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 40,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xFF59B8BE),
                  ),
                  child:
                      Center(child: textcostam("Login", 16, AppColor.kWhite)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
