// ignore_for_file: camel_case_types, prefer_typing_uninitialized_variables

import 'package:autowheel/contacts/colors.dart';
import 'package:autowheel/screen/sac_code.dart';
import 'package:autowheel/screen/spare_parts_cetegory.dart';
import 'package:autowheel/utils/text.dart';
import 'package:autowheel/utils/textformfildes.dart';
// ignore: unnecessary_import
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Create_Service extends StatefulWidget {
  const Create_Service({super.key});

  @override
  State<Create_Service> createState() => _Create_ServiceState();
}

class _Create_ServiceState extends State<Create_Service> {
  final formkey = GlobalKey<FormState>();
  var servicenamecon = TextEditingController();
  var servicecodecon = TextEditingController();
  var sarvicebarcodecon = TextEditingController();
  var ratecon = TextEditingController();
  var saccode = TextEditingController();
  bool _switchValue = false;
  // ignore: non_constant_identifier_names
  var Tax = TextEditingController();
  var h, w;

  bool index = false;
  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: const Color.fromARGB(255, 82, 198, 86), elevation: 5,

          title: textcostam("Create Service", 22, AppColor.kWhite),
          // ignore: prefer_const_literals_to_create_immutables
          actions: [
            const Padding(
              padding: EdgeInsets.only(right: 10),
              child: Icon(Icons.more_vert),
            )
          ],
        ),
        body: Padding(
          padding:
              const EdgeInsets.only(top: 20, right: 10, left: 10, bottom: 10),
          child: Form(
            key: formkey,
            child: Column(
              children: [
                // ignore: body_might_complete_normally_nullable
                textformfiles(servicenamecon,
                    // ignore: body_might_complete_normally_nullable
                    validator: (value) {
                  if (value!.isEmpty) {
                    return "Please Enter Name";
                  }
                }, label: textcostam("Service Name *", 16, AppColor.kBlack)),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: 150,
                      child: textformfiles(servicecodecon, validator: (p0) {
                        return null;
                      },
                          label:
                              textcostam("Service code", 16, AppColor.kBlack),
                          keyboardType: TextInputType.number),
                    ),
                    SizedBox(
                      width: w * 0.18,
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(50)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            "assets/WhatsApp Image 2023-08-26 at 4.02.24 PM.jpeg",
                            height: 80,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                // ignore: sized_box_for_whitespace
                Container(
                  height: 45,
                  width: double.infinity,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 150,
                        child: textformfiles(ratecon, validator: (p0) {
                          return null;
                        },
                            label: textcostam("MRP *", 15, AppColor.kBlack),
                            keyboardType: TextInputType.number),
                      ),
                      const SizedBox(
                        width: 28,
                      ),
                      textcostam("Tax Applicable", 12, AppColor.kBlack),
                      const SizedBox(
                        width: 8,
                      ),
                      InkWell(
                        onTap: () {
                          _switchValue = !_switchValue;
                          setState(() {});
                        },
                        child: Container(
                          height: 25,
                          width: 45,
                          decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 226, 223, 223),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: AppColor.kBlack,
                              )),
                          child: Switch(
                            inactiveThumbColor: Colors.grey,
                            inactiveTrackColor:
                                const Color.fromARGB(255, 222, 220, 220),
                            activeColor: Colors.blue,
                            value: _switchValue,
                            onChanged: (value) {
                              _switchValue = _switchValue;
                              // ignore: avoid_print
                              print("VALUE : $value");
                              setState(() {
                                _switchValue = value;
                              });
                            },
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        if (_switchValue == true) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  // ignore: prefer_const_constructors
                                  builder: (context) => Sac_Code()));
                        }
                      },
                      child: Container(
                        height: 45,
                        width: 150,
                        decoration: BoxDecoration(
                            border: Border.all(color: AppColor.kBlack),
                            borderRadius: BorderRadius.circular(8)),
                        child: Row(
                          children: [
                            const SizedBox(
                              width: 10,
                            ),
                            const Icon(
                              Icons.code,
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            textcostam("Sac Code", 15, AppColor.kBlack)
                          ],
                        ),
                      ),
                    ),
                    SizedBox(width: w * 0.05),
                    SizedBox(
                        width: w * 0.15,
                        child: textformfiles(saccode, validator: (p0) {
                          return null;
                        }, hintText: "IGST", readOnly: true)),
                    SizedBox(width: w * 0.025),
                    SizedBox(
                        width: w * 0.15,
                        child:
                            textformfiles(sarvicebarcodecon, validator: (p0) {
                          return null;
                        }, hintText: "CGST", readOnly: true)),
                    SizedBox(width: w * 0.025),
                    SizedBox(
                        width: w * 0.15,
                        child:
                            textformfiles(sarvicebarcodecon, validator: (p0) {
                          return null;
                        }, hintText: "SGST", readOnly: true))
                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const Spare_Parts_cetegory()));
                  },
                  child: Container(
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppColor.kBlack)),
                    child: Row(
                      children: [
                        const SizedBox(
                          width: 5,
                        ),
                        const Icon(
                          Icons.settings,
                          size: 20,
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        textcostam("Service Type", 16, AppColor.kBlack)
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                GestureDetector(
                  onTap: () {
                    // ignore: empty_statements
                    if (formkey.currentState!.validate()) ;
                  },
                  child: Container(
                    height: h * 0.05,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: const Color(0xFF59B8BE),
                        borderRadius: BorderRadius.circular(20)),
                    child: const Center(
                        child: Text(
                      "Save",
                      style: TextStyle(
                        color: AppColor.kWhite,
                        fontSize: 18,
                      ),
                    )),
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}
