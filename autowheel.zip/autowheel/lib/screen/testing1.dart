import 'package:flutter/material.dart';
import 'package:csc_picker/csc_picker.dart';

class dffdfer extends StatefulWidget {
  const dffdfer({super.key});

  @override
  State<dffdfer> createState() => _dffdferState();
}

String countryValue = "";











String stateValue = "";
String cityValue = "";
String address = "";

class _dffdferState extends State<dffdfer> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            SizedBox(
              height: 15,
            ),
            CSCPicker(
              showStates: true,
              showCities: true,
              dropdownDecoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(5)),
                  color: Colors.white,
                  border: Border.all(color: Colors.black, width: 0)),
              disabledDropdownDecoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(5)),
                  color: Colors.grey.shade300,
                  border: Border.all(color: Colors.grey.shade300, width: 1)),
              countryDropdownLabel: "Select Country",
              stateDropdownLabel: " Select State",
              cityDropdownLabel: " Select City",
              selectedItemStyle: TextStyle(
                color: Colors.black,
                fontSize: 14,
              ),
              dropdownHeadingStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 17,
                  fontWeight: FontWeight.bold),
              dropdownItemStyle: TextStyle(
                color: Colors.black,
                fontSize: 14,
              ),
              dropdownDialogRadius: 10.0,
              searchBarRadius: 10.0,
              onCountryChanged: (value) {
                setState(() {
                  countrySearchPlaceholder:
                  "$cityValue";
                  stateSearchPlaceholder:
                  "$cityValue";
                  citySearchPlaceholder:
                  "City";

                  countryValue = value;
                });
              },
              onStateChanged: (value) {
                setState(() {
                  stateValue = "$stateValue";
                });
              },
              onCityChanged: (value) {
                setState(() {
                  cityValue = "$countryValue";
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
