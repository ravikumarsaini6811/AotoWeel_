// ignore_for_file: camel_case_types, duplicate_ignore, prefer_typing_uninitialized_variables, unused_import

import 'package:autowheel/contacts/colors.dart';
import 'package:autowheel/screen/create_service.dart';
import 'package:autowheel/screen/location_master.dart';
import 'package:autowheel/screen/sac_code.dart';
import 'package:autowheel/utils/text.dart';
import 'package:csc_picker/csc_picker.dart';
import 'package:flutter/material.dart';

import '../utils/textformfildes.dart';
import 'Staff_master2.dart';

// ignore: camel_case_types
class Staff_master extends StatefulWidget {
  const Staff_master({super.key});

  @override
  State<Staff_master> createState() => _Staff_masterState();
}

String countryValue = "";
String stateValue = "";
String cityValue = "";
String address = "";
String relation = "M/s";
List _relate = ['M/s', 'Mr.', 'Mrs.', "Miss", "Dr."];
String city = "State";
// ignore: non_constant_identifier_names
List City = [
  "State",
];
String account = "Staff Designation *";
List _account = [
  "Staff Designation *",
  "CRM",
  "Mechanic ",
  "Work Manager",
  "Work Supervisor",
  "owner"
];

String crm = "Department *";
List _crm = [
  "Department *",
  "Accounts",
  "Bank Office",
  "Sales",
  "Servies",
  "Spase"
];
// ignore: non_constant_identifier_names
String show_room = "Location";
List _showroom = ["Location"];

class _Staff_masterState extends State<Staff_master> {
  var titlecontroller = TextEditingController();
  var namecontroller = TextEditingController();
  // ignore: non_constant_identifier_names
  var s_ocontroller = TextEditingController();
  var addresscontroller = TextEditingController();
  var districcontroller = TextEditingController();
  var mobilecontroller = TextEditingController();
  var stdcodecontroller = TextEditingController();
  // ignore: non_constant_identifier_names
  var Statecontroller = TextEditingController();
  var pincontroller = TextEditingController();
  var h, w;
  bool isSearchMode = false;
  bool index = true;

  final formkey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Form(
      key: formkey,
      child: Scaffold(
          appBar: AppBar(
            centerTitle: true,
            elevation: 5,
            backgroundColor: const Color.fromARGB(255, 82, 198, 86),
            title: textcostam("Staff Master", 22, AppColor.kBlack),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (contect) => const Staff_master2()));
                  },
                  child: const Icon(
                    Icons.search,
                    color: AppColor.kBlack,
                  ),
                ),
              )
            ],
          ),
          body: Padding(
            padding: EdgeInsets.only(
                right: w * 0.03, left: w * 0.03, bottom: h * 0.03),
            child: ListView(
              // ignore: prefer_const_constructors
              physics: BouncingScrollPhysics(),
              children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SizedBox(
                    height: h * 0.03,
                  ),
                  SizedBox(
                    width: w * 0.02,
                  ),
                  SizedBox(
                      child: textformfiles(
                    titlecontroller,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Enter Staff  Name";
                      }
                      return null;
                    },
                    label: SizedBox(
                      width: w * 0.3,
                      child: Row(
                        children: [
                          Icon(
                            Icons.person,
                            color: AppColor.kGray,
                            size: h * 0.024,
                          ),
                          SizedBox(
                            width: w * 0.02,
                          ),
                          textcostam(
                              "Staff Name *", h * 0.015, AppColor.kBlack),
                        ],
                      ),
                    ),
                    prefixIcon: Container(
                      padding: const EdgeInsets.all(8),
                      margin: const EdgeInsets.only(right: 10),
                      height: h * 0.04,
                      width: w * 0.20,
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.black),
                          borderRadius: BorderRadius.circular(8)),
                      child: DropdownButton(
                        underline: Container(),
                        value: relation,
                        dropdownColor: const Color.fromARGB(255, 211, 247, 212),
                        icon: Icon(Icons.keyboard_arrow_down_outlined,
                            size: h * 0.030, color: AppColor.kBlack),
                        isExpanded: true,
                        items: _relate.map((value) {
                          return DropdownMenuItem(
                            value: value,
                            child: Text(
                              value,
                            ),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            relation = value.toString();
                          });
                        },
                      ),
                    ),
                  )),
                  const SizedBox(
                    height: 10,
                  ),
                  textformfiles(s_ocontroller, validator: (value) {
                    return null;
                  }, label: textcostam("S/O", 16, AppColor.kBlack)),
                  const SizedBox(
                    height: 10,
                  ),
                  textformfiles(
                    addresscontroller,
                    validator: (value) {
                      return null;
                    },
                    label: textcostam("Phone Number", 16, AppColor.kBlack),
                    keyboardType: TextInputType.number,
                    maxLength: 10,
                    prefixIcon: Icon(
                      Icons.phone,

                      size: h * 0.024,
                      // Color.fromARGB(255, 36, 137, 39),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CSCPicker(
                        showStates: true,
                        showCities: true,
                        dropdownDecoration: BoxDecoration(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(5)),
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.black,
                            )),
                        disabledDropdownDecoration: BoxDecoration(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(5)),
                            color: Colors.white,
                            border: Border.all(color: Colors.black, width: 1)),
                        countryDropdownLabel: "Select Country *",
                        stateDropdownLabel: " Select State *",
                        cityDropdownLabel: " Select City *",
                        selectedItemStyle: const TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                        ),
                        dropdownHeadingStyle: const TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                        dropdownItemStyle: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        dropdownDialogRadius: 10.0,
                        searchBarRadius: 10.0,
                        onCountryChanged: (value) {
                          setState(() {
                            countrySearchPlaceholder:
                            "$cityValue";
                            stateSearchPlaceholder:
                            "$cityValue";
                            citySearchPlaceholder:
                            "City";

                            countryValue = value;
                          });
                        },
                        onStateChanged: (value) {
                          setState(() {
                            stateValue = "$stateValue";
                          });
                        },
                        onCityChanged: (value) {
                          setState(() {
                            cityValue = "$countryValue";
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: w * 0.46,
                        child: textformfiles(pincontroller, validator: (value) {
                          return null;
                        },
                            label: textcostam("Pin Code", 16, AppColor.kBlack),
                            keyboardType: TextInputType.number),
                      ),
                      SizedBox(
                        width: w * 0.03,
                      ),
                      SizedBox(
                          width: w * 0.442,
                          child: textformfiles(stdcodecontroller,
                              keyboardType: TextInputType.number,
                              validator: (value) {
                            return null;
                          },
                              label:
                                  textcostam("STD Code", 16, AppColor.kBlack)))
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  textformfiles(mobilecontroller, validator: (value) {
                    return null;
                  },
                      label: textcostam("Address", 16, AppColor.kBlack),
                      prefixIcon: Icon(
                        Icons.home,
                        size: h * 0.024,
                      )),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    height: h * 0.047,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black54),
                        borderRadius: BorderRadius.circular(5)),
                    child: DropdownButton(
                      hint: textcostam("Department**", 18, AppColor.kBlack),
                      underline: Container(),
                      value: crm,
                      dropdownColor: const Color.fromARGB(255, 211, 247, 212),
                      icon: Icon(Icons.keyboard_arrow_down_outlined,
                          size: h * 0.028, color: AppColor.kBlack),
                      isExpanded: true,
                      items: _crm.map((value) {
                        return DropdownMenuItem(
                          value: value,
                          child: Text(
                            value,
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          crm = value.toString();
                        });
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    height: h * 0.047,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black54),
                        borderRadius: BorderRadius.circular(5)),
                    child: DropdownButton(
                      borderRadius: BorderRadius.circular(20),
                      underline: Container(),
                      value: account,
                      dropdownColor: const Color.fromARGB(255, 211, 247, 212),
                      icon: Icon(Icons.keyboard_arrow_down_outlined,
                          size: h * 0.028, color: AppColor.kBlack),
                      isExpanded: true,
                      isDense: true,
                      itemHeight: 50,
                      items: _account.map((value) {
                        return DropdownMenuItem(
                          value: value,
                          child: Text(
                            value,
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          account = value.toString();
                        });
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    height: h * 0.047,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black54),
                        borderRadius: BorderRadius.circular(5)),
                    child: DropdownButton(
                      underline: Container(),
                      value: show_room,
                      dropdownColor: const Color.fromARGB(255, 211, 247, 212),
                      icon: Icon(Icons.keyboard_arrow_down_outlined,
                          size: h * 0.028, color: AppColor.kBlack),
                      isExpanded: true,
                      items: _showroom.map((value) {
                        return DropdownMenuItem(
                          value: value,
                          child: Row(
                            children: [
                              const Icon(
                                Icons.location_on,
                                color: AppColor.kGray,
                                size: 18,
                              ),
                              const SizedBox(
                                width: 0.1,
                              ),
                              Text(
                                value,
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          show_room = value.toString();
                        });
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  InkWell(
                    onTap: () {
                      if (formkey.currentState!.validate()) {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Create_Service()));
                      }
                    },
                    child: Container(
                      height: h * 0.05,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: const Color(0xFF59B8BE),
                          borderRadius: BorderRadius.circular(20)),
                      child: const Center(
                          child: Text(
                        "Save",
                        style: TextStyle(
                          color: AppColor.kBlack,
                          fontSize: 20,
                        ),
                      )),
                    ),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  InkWell(
                    onTap: () {
                      if (formkey.currentState!.validate()) {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Lacation_master()));
                      }
                    },
                    child: Container(
                      height: h * 0.05,
                      decoration: (BoxDecoration(
                          color: const Color.fromARGB(255, 250, 101, 90),
                          borderRadius: BorderRadius.circular(20))),
                      width: double.infinity,
                      child: const Center(
                          child: Text(
                        'Delete',
                        style: TextStyle(
                          color: AppColor.kBlack,
                          fontSize: 20,
                        ),
                      )),
                    ),
                  ),
                ]),
              ],
            ),
          )),
    );
  }
}
