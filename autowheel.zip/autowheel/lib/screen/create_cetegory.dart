// ignore_for_file: camel_case_types, non_constant_identifier_names, prefer_typing_uninitialized_variables

import 'package:autowheel/contacts/colors.dart';
import 'package:autowheel/utils/text.dart';
import 'package:autowheel/utils/textformfildes.dart';
import 'package:flutter/material.dart';

class Create_Cetegory extends StatefulWidget {
  const Create_Cetegory({super.key});

  @override
  State<Create_Cetegory> createState() => _Create_CetegoryState();
}

class _Create_CetegoryState extends State<Create_Cetegory> {
  final formkey = GlobalKey<FormState>();
  var entrycontroller = TextEditingController();
  var Pricepoolcontroller = TextEditingController();
  var saccontroller = TextEditingController();
  bool isSearchMode = false;
  var h, w;
  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        iconTheme: const IconThemeData(color: AppColor.kBlack),
        elevation: 5,
        backgroundColor: const Color.fromARGB(255, 82, 198, 86),
        title: textcostam("Sac Code", 22, AppColor.kBlack),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 10, right: 10, left: 10),
        child: Form(
          key: formkey,
          child: Column(
            children: [
              const SizedBox(
                height: 20,
              ),
              textformfiles(saccontroller,
                  // ignore: body_might_complete_normally_nullable
                  validator: (value) {
                if (value!.isEmpty) {
                  return "Please Enter Sac Code";
                }
              },
                  label: textcostam("Sac Code", 15, AppColor.kBlack),
                  prefixIcon: const Icon(
                    Icons.code,
                    color: AppColor.kGray,
                  )),
              const SizedBox(
                height: 18,
              ),
              Row(
                children: [
                  SizedBox(
                    width: w * 0.28,
                    child: textformfiles(entrycontroller, validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Enter IGST";
                      }
                      return null;
                    }, onChanged: (value) {
                      if (entrycontroller.text.isNotEmpty) {
                        String poolPrice = (int.parse(entrycontroller.text) / 2)
                            .toStringAsFixed(2);
                        Pricepoolcontroller.text = poolPrice;
                        setState(() {});
                      } else {
                        Pricepoolcontroller.clear();
                        setState(() {});
                      }
                      setState(() {});
                    },
                        keyboardType: TextInputType.number,
                        maxLength: 2,
                        label: textcostam("IGST", 14, AppColor.kBlack)),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  SizedBox(
                    width: w * 0.28,
                    child: textformfiles(readOnly: true, Pricepoolcontroller,
                        validator: (value) {
                      if (value!.isEmpty) {
                        return "";
                      }
                      return null;
                    }, label: textcostam("CGST", 14, AppColor.kBlack)),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  SizedBox(
                    width: w * 0.28,
                    child: textformfiles(readOnly: true, Pricepoolcontroller,
                        validator: (value) {
                      if (value!.isEmpty) {
                        return "";
                      }
                      return null;
                    }, label: textcostam("SGST", 14, AppColor.kBlack)),
                  ),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              GestureDetector(
                onTap: () {
                  if (formkey.currentState!.validate()) {}
                },
                child: Container(
                  height: h * 0.05,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: const Color(0xFF59B8BE),
                  ),
                  child: Center(
                      child: textcostam("Save Details", 16, AppColor.kWhite)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
