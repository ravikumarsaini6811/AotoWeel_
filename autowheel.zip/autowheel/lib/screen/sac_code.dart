// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, duplicate_ignore

import 'package:autowheel/contacts/colors.dart';
import 'package:autowheel/screen/create_cetegory.dart';
import 'package:autowheel/utils/text.dart';
import 'package:autowheel/utils/textformfildes.dart';
import 'package:flutter/material.dart';

// ignore: camel_case_types
class Sac_Code extends StatefulWidget {
  const Sac_Code({super.key});

  @override
  State<Sac_Code> createState() => _Sac_CodeState();
}

// ignore: camel_case_types
class _Sac_CodeState extends State<Sac_Code> {
  var cetegorycon = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: GestureDetector(
        onTap: () {
          // ignore: duplicate_ignore
          Navigator.push(
              context,
              // ignore: prefer_const_constructors
              MaterialPageRoute(builder: (context) => Create_Cetegory()));
        },
        child: Container(
          height: 50,
          width: 120,
          decoration: BoxDecoration(
              // ignore: prefer_const_constructors
              color: Color.fromARGB(255, 136, 180, 216),
              borderRadius: BorderRadius.circular(10),
              // ignore: prefer_const_constructors
              boxShadow: [BoxShadow(blurRadius: 2)]),
          child: Padding(
            padding: const EdgeInsets.only(
              left: 10,
            ),
            child: Row(
              children: [
                // ignore: prefer_const_constructors
                Icon(
                  Icons.add,
                  size: 20,
                ),
                SizedBox(
                  width: 10,
                ),
                textcostam("Sac Code", 15, AppColor.kBlack)
              ],
            ),
          ),
        ),
      ),
      appBar: AppBar(
        iconTheme: IconThemeData(color: AppColor.kBlack),
        backgroundColor: Color.fromARGB(255, 82, 198, 86),
        elevation: 5,
        centerTitle: false,
        title: textcostam("Sac Code", 18, AppColor.kBlack),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 30, right: 10, left: 10),
        child: Column(
          children: [
            textformfiles(cetegorycon,
                // ignore: body_might_complete_normally_nullable
                validator: (p0) {},
                label: textcostam("Type here", 15, AppColor.kGray),
                prefixIcon: Icon(Icons.search)),
          ],
        ),
      ),
    );
  }
}
