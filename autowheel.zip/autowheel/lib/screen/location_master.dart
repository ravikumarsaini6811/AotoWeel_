// ignore_for_file: camel_case_types, prefer_typing_uninitialized_variables, prefer_const_constructors, duplicate_ignore, body_might_complete_normally_nullable, unnecessary_string_interpolations

import 'package:autowheel/screen/Staff_master2.dart';
import 'package:autowheel/screen/servicce_Type.dart';
import 'package:autowheel/screen/staff_master.dart';
import 'package:autowheel/utils/text.dart';
import 'package:csc_picker/csc_picker.dart';
import 'package:flutter/material.dart';

import '../contacts/colors.dart';
import '../utils/textformfildes.dart';

class Lacation_master extends StatefulWidget {
  const Lacation_master({super.key});

  @override
  State<Lacation_master> createState() => _Lacation_masterState();
}

String city = "State";
// ignore: non_constant_identifier_names
List City = [
  "State",
];

class _Lacation_masterState extends State<Lacation_master> {
  var namecontroller = TextEditingController();
  // ignore: non_constant_identifier_names
  var location_con = TextEditingController();
  final formkey = GlobalKey<FormState>();
  var refcon = TextEditingController();
  var groupcon = TextEditingController();
  var phonecon = TextEditingController();
  var addresscon = TextEditingController();
  var addresscon1 = TextEditingController();
  var gst = TextEditingController();
  // ignore: non_constant_identifier_names
  var Statecontroller = TextEditingController();
  var pincontroller = TextEditingController();
  var h, w;
  String city = "State";
// ignore: non_constant_identifier_names
  List City = [
    "State",
  ];
  bool isSearchMode = false;
  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 82, 198, 86),
        elevation: 5,
        title: textcostam("Location", 22, AppColor.kBlack),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: GestureDetector(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: ((context) => Staff_master2())));
              },
              child: Icon(
                Icons.search,
                color: Colors.black,
              ),
            ),
          )
        ],
      ),
      body: Padding(
        padding:
            const EdgeInsets.only(left: 10, right: 10, top: 20, bottom: 10),
        child: ListView(
          physics: BouncingScrollPhysics(),
          children: [
            Form(
              key: formkey,
              child: Column(
                children: [
                  textformfiles(location_con, validator: (value) {
                    if (value!.isEmpty) {
                      return "Please Enter Location Name*";
                    }
                  },
                      label: textcostam("Location Name", 16, AppColor.kBlack),
                      prefixIcon: Icon(Icons.location_on)),
                  SizedBox(
                    height: 10,
                  ),
                  textformfiles(refcon,
                      validator: (value) {},
                      label: textcostam("Location Ref", 16, AppColor.kBlack),
                      prefixIcon: Icon(Icons.location_on)),
                  SizedBox(
                    height: 10,
                  ),
                  textformfiles(groupcon,
                      validator: (value) {},
                      label: textcostam("Group", 16, AppColor.kBlack),
                      prefixIcon: Icon(Icons.group)),
                  SizedBox(
                    height: 10,
                  ),
                  textformfiles(phonecon,
                      validator: (value) {},
                      label: textcostam("Contact No.", 16, AppColor.kBlack),
                      prefixIcon: Icon(Icons.phone),
                      keyboardType: TextInputType.number,
                      maxLength: 10),
                  SizedBox(
                    height: 10,
                  ),
                  textformfiles(gst,
                      validator: (value) {},
                      label: Row(
                        children: [
                          textcostam(
                            "GST Number ",
                            16,
                            AppColor.kBlack,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          textcostam(
                            "(Optional)",
                            16,
                            AppColor.kGray,
                          )
                        ],
                      ),
                      maxLength: 15, onChanged: (value) {
                    gst.value = TextEditingValue(
                        text: value.toUpperCase(), selection: gst.selection);
                  },
                      prefixIcon: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            "assets/WhatsApp Image 2023-08-26 at 6.26.14 PM.jpeg",
                            height: 25,
                          ),
                        ],
                      ),
                      textCapitalization: TextCapitalization.sentences),
                  SizedBox(
                    height: 10,
                  ),
                  textformfiles(addresscon, validator: (value) {
                    if (value!.isEmpty) {
                      return "Please Enter Address";
                    }
                  },
                      label: textcostam("Address", 16, AppColor.kBlack),
                      prefixIcon: Icon(Icons.home)),
                  SizedBox(
                    height: 10,
                  ),
                  textformfiles(
                    addresscon1,
                    validator: (value) {},
                    label: textcostam("Address Line 2", 16, AppColor.kBlack),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CSCPicker(
                        showStates: true,
                        showCities: true,
                        dropdownDecoration: BoxDecoration(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(5)),
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.black,
                            )),
                        disabledDropdownDecoration: BoxDecoration(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(5)),
                            color: Colors.white,
                            border: Border.all(color: Colors.black, width: 1)),
                        countryDropdownLabel: "Select Country *",
                        stateDropdownLabel: " Select State *",
                        cityDropdownLabel: " Select City *",
                        selectedItemStyle: const TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                        ),
                        dropdownHeadingStyle: const TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                        dropdownItemStyle: const TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                        ),
                        dropdownDialogRadius: 10.0,
                        searchBarRadius: 10.0,
                        onCountryChanged: (value) {
                          setState(() {
                            // ignore: unused_label
                            countrySearchPlaceholder:
                            "$cityValue";
                            // ignore: unused_label
                            stateSearchPlaceholder:
                            "$cityValue";
                            // ignore: unused_label
                            citySearchPlaceholder:
                            "City";

                            countryValue = value;
                          });
                        },
                        onStateChanged: (value) {
                          setState(() {
                            stateValue = "$stateValue";
                          });
                        },
                        onCityChanged: (value) {
                          setState(() {
                            cityValue = "$countryValue";
                          });
                        },
                      ),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.012,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: w * 0.45,
                        child: textformfiles(pincontroller, validator: (value) {
                          return null;
                        },
                            label: textcostam("Pin Code ", 16, AppColor.kBlack),
                            keyboardType: TextInputType.number),
                      ),
                      SizedBox(
                        width: w * 0.45,
                        child: textformfiles(pincontroller, validator: (value) {
                          return null;
                        },
                            label: textcostam("STD Code", 16, AppColor.kBlack),
                            keyboardType: TextInputType.number),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  GestureDetector(
                    onTap: () {
                      // ignore: empty_statements
                      if (formkey.currentState!.validate()) ;
                    },
                    child: Container(
                      height: h * 0.05,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: const Color(0xFF59B8BE),
                          borderRadius: BorderRadius.circular(20)),
                      child: const Center(
                          child: Text(
                        "Save",
                        style: TextStyle(
                          color: AppColor.kWhite,
                          fontSize: 18,
                        ),
                      )),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
