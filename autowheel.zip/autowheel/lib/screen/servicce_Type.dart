// ignore: duplicate_ignore
// ignore: file_names
// ignore: file_names
// ignore: file_names
// ignore_for_file: file_names, duplicate_ignore, body_might_complete_normally_nullable, prefer_typing_uninitialized_variables, unused_field, prefer_final_fields

import 'package:autowheel/contacts/colors.dart';
import 'package:autowheel/utils/text.dart';
import 'package:autowheel/utils/textformfildes.dart';
// ignore: unnecessary_import
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: camel_case_types
class Service_Name extends StatefulWidget {
  const Service_Name({super.key});

  @override
  State<Service_Name> createState() => _Create_CetegoryState();
}

// ignore: camel_case_types
class _Create_CetegoryState extends State<Service_Name> {
  final formkey = GlobalKey<FormState>();
  var entrycontroller = TextEditingController();
  // ignore: non_constant_identifier_names
  var Pricepoolcontroller = TextEditingController();
  var saccontroller = TextEditingController();
  var h, w;
  bool _switchValue = true;
  bool isSearchMode = false;
  @override
  Widget build(BuildContext context) {
    h = MediaQuery.of(context).size.height;
    w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        // ignore: prefer_const_constructors
        iconTheme: IconThemeData(color: AppColor.kBlack),
        elevation: 2,
        backgroundColor: Color.fromARGB(255, 82, 198, 86),
        title: Text(
          'Service Type',
          style: TextStyle(color: AppColor.kBlack, fontSize: 18),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 10, right: 10, left: 10),
        child: Form(
          key: formkey,
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              textformfiles(saccontroller, validator: (value) {
                if (value!.isEmpty) {
                  return "Please Enter Service Name";
                }
              },
                  label: textcostam("Service Name", 15, AppColor.kBlack),
                  prefixIcon: const Icon(
                    Icons.settings,
                    color: AppColor.kBlack,
                    size: 20,
                  )),
              const SizedBox(
                height: 30,
              ),
              GestureDetector(
                onTap: () {
                  if (formkey.currentState!.validate()) {}
                },
                child: Container(
                  height: h * 0.05,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Color(0xFF59B8BE),
                  ),
                  child: Center(
                      child: textcostam("Save Details", 16, AppColor.kWhite)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
