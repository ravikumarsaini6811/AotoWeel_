// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, duplicate_ignore

import 'package:autowheel/contacts/colors.dart';
import 'package:autowheel/screen/create_cetegory.dart';
import 'package:autowheel/utils/text.dart';
import 'package:autowheel/utils/textformfildes.dart';
import 'package:flutter/material.dart';

// ignore: camel_case_types
class Staff_master2 extends StatefulWidget {
  const Staff_master2({super.key});

  @override
  State<Staff_master2> createState() => _Staff_master2State();
}

// ignore: camel_case_types
class _Staff_master2State extends State<Staff_master2> {
  var cetegorycon = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: AppColor.kBlack),
        backgroundColor: Color.fromARGB(255, 82, 198, 86),
        elevation: 5,
        centerTitle: false,
        title: textcostam("Staff Master", 22, AppColor.kBlack),
      ),
      body: Padding(
        padding: const EdgeInsets.only(right: 10, left: 10),
        child: Column(
          children: [
            SizedBox(
              height: 20,
            ),
            textformfiles(cetegorycon,
                // ignore: body_might_complete_normally_nullable
                validator: (p0) {},
                label: textcostam("Type here", 15, AppColor.kGray),
                prefixIcon: Icon(Icons.search)),
          ],
        ),
      ),
    );
  }
}
